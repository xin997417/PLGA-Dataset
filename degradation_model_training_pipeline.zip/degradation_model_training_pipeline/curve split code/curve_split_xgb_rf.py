import os
import re
import json
import warnings

import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt

from bayes_opt import BayesianOptimization
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.base import clone
from sklearn.ensemble import RandomForestRegressor

try:
    from xgboost import XGBRegressor
    HAS_XGB = True
except Exception:
    HAS_XGB = False

warnings.filterwarnings("ignore")

np.random.seed(42)

file_path = r""
output_root = r""

VAL_SHEET_NAME = "Validation"
TIME_COL = "Time"
Y_COL = "degradation amount"

base_numeric_cols = ["Mw", "Ratio", "T", "pH", "SA/V", "LA_type", "Time"]
categorical_cols = ["Shape"]

ADD_TIME_FEATURES = True
TIME_NORM_COL = "t_norm"
LOG_TIME_COL = "log_time"
TIME_SQ_COL = "time_sq"

BO_INIT_POINTS = 12
BO_N_ITER = 120

CURVE_TEST_SIZE = 0.2
SPLIT_BINS = 5

APPLY_T0_ANCHOR = True
APPLY_NONNEG = True

USE_GAP_PENALTY = False
GAP_PENALTY_LAMBDA = 0.0

CV_N_SPLITS = 5
CV_STRAT_BINS = 5

XGB_USE_EARLY_STOP = True
XGB_EARLY_STOP_ROUNDS = 300
XGB_INTERNAL_HOLDOUT_FRAC = 0.25

STRICT_NO_LEAK = True

SAVE_VAL_PLOTS = True
VAL_PLOTS_DPI = 600

USE_MEDIAN_OBJECTIVE = True
USE_BASELINE_FALLBACK = True


def safe_name(s: str) -> str:
    return re.sub(r"[^0-9A-Za-z]+", "_", str(s)).strip("_")


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.ndarray,)):
        return o.tolist()
    return str(o)


def _clean_df_basic(df: pd.DataFrame) -> pd.DataFrame:
    df = df.loc[:, ~df.columns.str.contains("^Unnamed", na=False)].copy()
    if TIME_COL not in df.columns or Y_COL not in df.columns:
        raise ValueError(f"Missing required columns: {TIME_COL} or {Y_COL}")
    df[TIME_COL] = pd.to_numeric(df[TIME_COL], errors="coerce")
    df[Y_COL] = pd.to_numeric(df[Y_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL, Y_COL]).reset_index(drop=True)
    return df


def add_curve_id_by_time0(df: pd.DataFrame, time_col: str):
    t = pd.to_numeric(df[time_col], errors="coerce").to_numpy(dtype=float)
    is_zero = np.isclose(t, 0.0, atol=1e-12)
    start_flags = np.zeros(len(df), dtype=bool)
    if len(df) > 0:
        start_flags[0] = True
    if len(df) > 1:
        start_flags[1:] = is_zero[1:] & (~is_zero[:-1])
    curve_id = np.cumsum(start_flags) - 1
    out = df.copy()
    out["curve_id"] = curve_id
    return out


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "curve_id" not in out.columns:
        raise ValueError("Missing curve_id; cannot compute t_norm.")
    grp = out.groupby("curve_id")[TIME_COL].max().rename("t_max_curve")
    out = out.join(grp, on="curve_id")
    tmax = out["t_max_curve"].to_numpy(dtype=float)
    t = out[TIME_COL].to_numpy(dtype=float)
    denom = np.where(tmax > 1e-12, tmax, 1.0)
    out[TIME_NORM_COL] = t / denom
    out[LOG_TIME_COL] = np.log1p(np.maximum(t, 0.0))
    out[TIME_SQ_COL] = t ** 2
    out = out.drop(columns=["t_max_curve"])
    return out


def build_preprocess(df: pd.DataFrame, numeric_cols, cat_cols):
    num_cols = list(numeric_cols)
    cat_cols = list(cat_cols)

    if "LA_type" in df.columns:
        if (df["LA_type"].dtype == "object") or (df["LA_type"].nunique() <= 20):
            if "LA_type" in num_cols:
                num_cols.remove("LA_type")
            if "LA_type" not in cat_cols:
                cat_cols.append("LA_type")

    feature_cols = num_cols + cat_cols

    try:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)

    preprocess = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_cols),
            ("cat", ohe, cat_cols),
        ],
        remainder="drop",
    )
    return preprocess, feature_cols, num_cols, cat_cols


def apply_constraints_pointwise(y_pred_raw: np.ndarray, t_arr: np.ndarray):
    y = np.asarray(y_pred_raw, dtype=float).copy()
    t = np.asarray(t_arr, dtype=float)

    if APPLY_T0_ANCHOR:
        mask0 = np.isclose(t, 0.0, atol=1e-12)
        if not np.any(mask0):
            mask0 = (t == np.nanmin(t))
        y[mask0] = 0.0

    if APPLY_NONNEG:
        y = np.maximum(y, 0.0)

    return y


def check_overlap_by_hash(df_pool: pd.DataFrame, df_val: pd.DataFrame):
    common_cols = [c for c in df_pool.columns if c in df_val.columns]
    if len(common_cols) == 0:
        return 0, []
    pool_h = pd.util.hash_pandas_object(df_pool[common_cols], index=False)
    val_h = set(pd.util.hash_pandas_object(df_val[common_cols], index=False).tolist())
    mask = pool_h.isin(val_h)
    cnt = int(mask.sum())
    samples = df_pool.loc[mask, common_cols].head(5).to_dict(orient="records") if cnt > 0 else []
    return cnt, samples


def build_curve_meta(df: pd.DataFrame):
    meta = df.groupby("curve_id", sort=True).agg(
        y_max=(Y_COL, "max"),
        t_max=(TIME_COL, "max"),
        n_points=(Y_COL, "size"),
    ).reset_index()
    meta["score"] = meta["y_max"].astype(float) + meta["t_max"].astype(float)
    return meta


def stratified_curve_split(df_pool: pd.DataFrame, curve_meta: pd.DataFrame, test_size=0.2, n_bins=5, seed=42):
    meta_pool = curve_meta[curve_meta["curve_id"].isin(df_pool["curve_id"].unique())].copy()
    meta_pool = meta_pool.sort_values("curve_id").reset_index(drop=True)
    score = meta_pool["score"].to_numpy(dtype=float)
    try:
        bins = pd.qcut(score, q=n_bins, duplicates="drop")
    except Exception:
        bins = pd.cut(score, bins=min(n_bins, len(meta_pool)), duplicates="drop")
    meta_pool["bin"] = bins.astype(str)

    rng = np.random.RandomState(seed)
    train_ids, test_ids = [], []
    for _, g in meta_pool.groupby("bin"):
        ids = g["curve_id"].astype(int).tolist()
        rng.shuffle(ids)
        if len(ids) <= 1:
            train_ids.extend(ids)
            continue
        n_test = max(1, int(round(len(ids) * test_size)))
        test_ids.extend(ids[:n_test])
        train_ids.extend(ids[n_test:])

    df_train = df_pool[df_pool["curve_id"].isin(train_ids)].copy()
    df_test = df_pool[df_pool["curve_id"].isin(test_ids)].copy()
    return df_train, df_test


def make_stratified_group_folds(curve_meta: pd.DataFrame, n_splits=5, n_bins=5, seed=42):
    meta = curve_meta.copy().sort_values("curve_id").reset_index(drop=True)
    score = meta["score"].to_numpy(dtype=float)
    try:
        bins = pd.qcut(score, q=n_bins, duplicates="drop")
    except Exception:
        bins = pd.cut(score, bins=min(n_bins, len(meta)), duplicates="drop")
    meta["bin"] = bins.astype(str)

    rng = np.random.RandomState(seed)
    folds = [[] for _ in range(n_splits)]
    for _, g in meta.groupby("bin"):
        ids = g["curve_id"].astype(int).tolist()
        rng.shuffle(ids)
        for i, cid in enumerate(ids):
            folds[i % n_splits].append(cid)

    all_ids = set(meta["curve_id"].astype(int).tolist())
    out = []
    for k in range(n_splits):
        val_ids = set(folds[k])
        tr_ids = list(all_ids - val_ids)
        out.append((tr_ids, list(val_ids)))
    return out


def set_matplotlib_font():
    try:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
        plt.rcParams["axes.unicode_minus"] = False
    except Exception:
        pass


def calc_metrics(y_true: np.ndarray, y_pred: np.ndarray):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_pred - y_true
    mae = float(mean_absolute_error(y_true, y_pred))
    ae = float(np.mean(err))
    mse = float(mean_squared_error(y_true, y_pred))
    rmse = float(np.sqrt(mse))
    r2 = float(r2_score(y_true, y_pred))
    denom = np.maximum(np.abs(y_true), 1e-6)
    mape = float(np.mean(np.abs(err) / denom) * 100.0)
    return {"MAE": mae, "AE": ae, "R2": r2, "RMSE": rmse, "MSE": mse, "MAPE": mape}


def plot_val_curves_per_model(model_name, df_val, feature_cols, preprocess, model, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    set_matplotlib_font()

    for cid, g in df_val.groupby("curve_id"):
        gg = g.sort_values(TIME_COL).reset_index(drop=True)
        X = gg[feature_cols]
        y_true = gg[Y_COL].to_numpy(dtype=float)
        t_arr = gg[TIME_COL].to_numpy(dtype=float)

        Xm = preprocess.transform(X)
        y_raw = model.predict(Xm)
        y_pred = apply_constraints_pointwise(y_raw, t_arr)
        m = calc_metrics(y_true, y_pred)

        fig = plt.figure(figsize=(8, 4.5))
        plt.plot(t_arr, y_true, marker="o", linewidth=2, label="True")
        plt.plot(t_arr, y_pred, marker="o", linewidth=2, label="Pred")
        plt.title(f"{model_name} | Val Curve ID={int(cid)}")
        plt.xlabel("Time")
        plt.ylabel(Y_COL)
        plt.grid(True, alpha=0.3)
        plt.legend(loc="upper left")

        txt = (
            f"MAE: {m['MAE']:.5f}\n"
            f"AE : {m['AE']:.5f}\n"
            f"R2 : {m['R2']:.5f}\n"
            f"RMSE:{m['RMSE']:.5f}\n"
            f"MSE: {m['MSE']:.5f}\n"
            f"MAPE:{m['MAPE']:.2f}%"
        )
        plt.gca().text(
            0.98, 0.02, txt,
            transform=plt.gca().transAxes,
            ha="right", va="bottom",
            bbox=dict(boxstyle="round", alpha=0.85, facecolor="white")
        )
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, f"curve_id_{int(cid)}.png"), dpi=VAL_PLOTS_DPI)
        plt.close(fig)


def save_best_params_json(out_dir, split_mode, model_name, payload):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{safe_name(split_mode)}__{safe_name(model_name)}__best_params.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=True, indent=2, default=_json_default)
    return path


def rf_build(params, return_decoded=False):
    decoded = {
        "random_state": 42,
        "n_estimators": int(round(params["n_estimators"])),
        "max_depth": None if params["max_depth"] < 1.5 else int(round(params["max_depth"])),
        "min_samples_split": max(2, int(round(params["min_samples_split"]))),
        "min_samples_leaf": max(1, int(round(params["min_samples_leaf"]))),
        "max_features": float(np.clip(params["max_features"], 0.2, 1.0)),
        "bootstrap": True,
        "n_jobs": -1,
    }
    max_samples = float(np.clip(params["max_samples"], 0.55, 1.0))
    try:
        m = RandomForestRegressor(**{**decoded, "max_samples": max_samples})
        decoded["max_samples"] = max_samples
    except TypeError:
        m = RandomForestRegressor(**decoded)
    return (m, decoded) if return_decoded else m


def xgb_build(params, return_decoded=False):
    if not HAS_XGB:
        raise RuntimeError("xgboost not detected. Please install it first: pip install xgboost")

    decoded = {
        "random_state": 42,
        "n_estimators": int(round(params["n_estimators"])),
        "learning_rate": float(10 ** params["log_learning_rate"]),
        "max_depth": int(round(params["max_depth"])),
        "subsample": float(np.clip(params["subsample"], 0.5, 1.0)),
        "colsample_bytree": float(np.clip(params["colsample_bytree"], 0.5, 1.0)),
        "min_child_weight": float(np.clip(params["min_child_weight"], 1.0, 40.0)),
        "gamma": float(np.clip(params["gamma"], 0.0, 10.0)),
        "reg_alpha": float(10 ** params["log_reg_alpha"]),
        "reg_lambda": float(10 ** params["log_reg_lambda"]),
        "max_delta_step": float(np.clip(params["max_delta_step"], 0.0, 10.0)),
        "objective": "reg:squarederror",
        "n_jobs": -1,
        "tree_method": "hist",
    }
    if XGB_USE_EARLY_STOP:
        decoded["eval_metric"] = "rmse"
        decoded["early_stopping_rounds"] = int(XGB_EARLY_STOP_ROUNDS)

    m = XGBRegressor(**decoded)
    return (m, decoded) if return_decoded else m


def curve_internal_holdout(df_train: pd.DataFrame, frac=0.25, seed=42):
    rng = np.random.RandomState(seed)
    curve_ids = np.array(sorted(df_train["curve_id"].unique()))
    if len(curve_ids) < 4 or frac <= 0:
        return df_train.copy(), None
    n_hold = max(1, int(round(len(curve_ids) * frac)))
    rng.shuffle(curve_ids)
    hold_ids = set(curve_ids[:n_hold].tolist())

    df_hold = df_train[df_train["curve_id"].isin(hold_ids)].copy()
    df_fit = df_train[~df_train["curve_id"].isin(hold_ids)].copy()
    if len(df_fit) == 0 or len(df_hold) == 0:
        return df_train.copy(), None
    return df_fit, df_hold


def fit_for_cv(model, X_tr_m, y_tr, X_va_m, y_va):
    if HAS_XGB and isinstance(model, XGBRegressor) and XGB_USE_EARLY_STOP:
        model.fit(X_tr_m, y_tr, eval_set=[(X_va_m, y_va)], verbose=False)
    else:
        model.fit(X_tr_m, y_tr)


def cv_stratified_curve_r2_and_gap(model_factory, X_df, y, df_with_curveid, preprocess, curve_meta_train):
    folds = make_stratified_group_folds(curve_meta_train, n_splits=CV_N_SPLITS, n_bins=CV_STRAT_BINS, seed=42)
    r2_list, gap_list = [], []

    for tr_curve_ids, va_curve_ids in folds:
        tr_mask = df_with_curveid["curve_id"].isin(tr_curve_ids).to_numpy()
        va_mask = df_with_curveid["curve_id"].isin(va_curve_ids).to_numpy()

        X_tr = X_df.loc[tr_mask].copy()
        y_tr = y[tr_mask]
        X_va = X_df.loc[va_mask].copy()
        y_va = y[va_mask]

        prep = clone(preprocess)
        X_tr_m = prep.fit_transform(X_tr)
        X_va_m = prep.transform(X_va)

        model = model_factory()
        fit_for_cv(model, X_tr_m, y_tr, X_va_m, y_va)

        y_va_raw = model.predict(X_va_m)
        y_va_pred = apply_constraints_pointwise(y_va_raw, X_va[TIME_COL].values)
        r2_va = float(r2_score(y_va, y_va_pred))
        r2_list.append(r2_va)

        y_tr_raw = model.predict(X_tr_m)
        y_tr_pred = apply_constraints_pointwise(y_tr_raw, X_tr[TIME_COL].values)
        r2_tr = float(r2_score(y_tr, y_tr_pred))
        gap_list.append(max(0.0, r2_tr - r2_va))

    r2_arr = np.array(r2_list, dtype=float)
    gap_arr = np.array(gap_list, dtype=float)

    r2_stat = float(np.nanmedian(r2_arr)) if USE_MEDIAN_OBJECTIVE else float(np.nanmean(r2_arr))
    gap_stat = float(np.nanmedian(gap_arr)) if USE_MEDIAN_OBJECTIVE else float(np.nanmean(gap_arr))
    return r2_stat, gap_stat, r2_list, gap_list


def run_bo(pbounds, builder, X_train_df, y_train, df_train, preprocess, curve_meta_train, init_points, n_iter):
    def objective(**params):
        try:
            def model_factory():
                return builder(dict(params))

            r2_stat, gap_stat, _, _ = cv_stratified_curve_r2_and_gap(
                model_factory, X_train_df, y_train, df_train, preprocess, curve_meta_train
            )
            if not np.isfinite(r2_stat):
                return -1e9
            if USE_GAP_PENALTY:
                return r2_stat - GAP_PENALTY_LAMBDA * gap_stat
            return r2_stat
        except Exception:
            return -1e9

    try:
        opt = BayesianOptimization(f=objective, pbounds=pbounds, random_state=42, allow_duplicate_points=True)
    except TypeError:
        opt = BayesianOptimization(f=objective, pbounds=pbounds, random_state=42)

    opt.maximize(init_points=int(init_points), n_iter=int(n_iter))

    best = opt.max
    best_params_raw = best["params"]
    best_target = float(best["target"])

    best_model, best_params_decoded = builder(best_params_raw, return_decoded=True)

    def best_factory():
        return builder(dict(best_params_raw))

    r2_stat, gap_stat, r2_list, gap_list = cv_stratified_curve_r2_and_gap(
        best_factory, X_train_df, y_train, df_train, preprocess, curve_meta_train
    )
    return best_model, best_params_decoded, best_target, float(r2_stat), float(gap_stat), r2_list, gap_list


def main():
    os.makedirs(output_root, exist_ok=True)
    out_models = os.path.join(output_root, "01_models")
    out_results = os.path.join(output_root, "02_results")
    out_params = os.path.join(output_root, "04_best_params_json")
    out_plots = os.path.join(output_root, "06_val_plots")

    for d in [out_models, out_results, out_params, out_plots]:
        os.makedirs(d, exist_ok=True)

    sheets = pd.read_excel(file_path, sheet_name=None, engine="openpyxl")
    if VAL_SHEET_NAME not in sheets:
        raise ValueError(f"Sheet not found in Excel: {VAL_SHEET_NAME}")

    df_val = _clean_df_basic(sheets[VAL_SHEET_NAME])

    train_parts = []
    for name, s in sheets.items():
        if name == VAL_SHEET_NAME:
            continue
        if TIME_COL in s.columns and Y_COL in s.columns:
            train_parts.append(_clean_df_basic(s))

    if not train_parts:
        raise ValueError("No usable training sheets found (excluding the validation sheet).")

    df_pool = pd.concat(train_parts, axis=0, ignore_index=True)

    if "curve_id" not in df_pool.columns:
        df_pool = add_curve_id_by_time0(df_pool, TIME_COL)
    if "curve_id" not in df_val.columns:
        df_val = add_curve_id_by_time0(df_val, TIME_COL)

    overlap_cnt, samples = check_overlap_by_hash(df_pool, df_val)
    print(f"[LeakCheck] Pool-VAL overlap rows = {overlap_cnt}")
    if overlap_cnt > 0:
        print("[LeakCheck] sample rows:", samples)
        if STRICT_NO_LEAK:
            raise ValueError(
                "Training pool still contains rows overlapping with the validation set. "
                "Please ensure validation rows are removed from other sheets or deduplicated."
            )

    if ADD_TIME_FEATURES:
        df_pool = add_time_features(df_pool)
        df_val = add_time_features(df_val)

    numeric_cols = list(base_numeric_cols)
    if ADD_TIME_FEATURES:
        numeric_cols += [TIME_NORM_COL, LOG_TIME_COL, TIME_SQ_COL]

    df_schema = pd.concat([df_pool, df_val], axis=0, ignore_index=True)
    preprocess, feature_cols, _, _ = build_preprocess(df_schema, numeric_cols, categorical_cols)

    curve_meta_pool = build_curve_meta(df_pool)
    df_train, df_test = stratified_curve_split(
        df_pool, curve_meta_pool, test_size=CURVE_TEST_SIZE, n_bins=SPLIT_BINS, seed=42
    )
    curve_meta_train = build_curve_meta(df_train)

    split_dir = os.path.join(output_root, "00_curve_split")
    os.makedirs(split_dir, exist_ok=True)
    train_curve_ids = sorted(df_train["curve_id"].unique().tolist())
    test_curve_ids = sorted(df_test["curve_id"].unique().tolist())
    with open(os.path.join(split_dir, "train_curve_ids.json"), "w", encoding="utf-8") as f:
        json.dump(train_curve_ids, f, indent=2)
    with open(os.path.join(split_dir, "test_curve_ids.json"), "w", encoding="utf-8") as f:
        json.dump(test_curve_ids, f, indent=2)

    print(f"Total rows={len(df_pool)} | curves={df_pool['curve_id'].nunique()}")
    print(
        f"Train rows={len(df_train)} curves={df_train['curve_id'].nunique()} | "
        f"Test rows={len(df_test)} curves={df_test['curve_id'].nunique()} | "
        f"Val rows={len(df_val)} curves={df_val['curve_id'].nunique()}"
    )

    X_train = df_train[feature_cols].copy()
    y_train = df_train[Y_COL].to_numpy(dtype=float)

    rf_pbounds = {
        "n_estimators": (800, 4500),
        "max_depth": (0.0, 28.0),
        "min_samples_split": (2, 60),
        "min_samples_leaf": (1, 25),
        "max_features": (0.20, 1.0),
        "max_samples": (0.55, 1.0),
    }

    xgb_pbounds = {
        "n_estimators": (1200, 20000),
        "log_learning_rate": (-2.3, -0.75),
        "max_depth": (2, 7),
        "subsample": (0.50, 1.0),
        "colsample_bytree": (0.50, 1.0),
        "min_child_weight": (1, 40),
        "gamma": (0.0, 10.0),
        "log_reg_alpha": (-8.0, 0.3),
        "log_reg_lambda": (-0.3, 2.3),
        "max_delta_step": (0.0, 10.0),
    }

    metrics_rows = []

    def add_metrics_rows(model_name: str, split_name: str, y_true, y_pred):
        m = calc_metrics(y_true, y_pred)
        metrics_rows.append(
            {
                "Model": model_name,
                "Split": split_name,
                "MAE": m["MAE"],
                "R2": m["R2"],
                "AE": m["AE"],
                "MSE": m["MSE"],
                "MAPE(%)": m["MAPE"],
            }
        )

    summary_rows = []

    baseline_xgb = None
    baseline_score = -1e9
    if HAS_XGB:
        baseline_params = dict(
            random_state=42,
            n_estimators=20000,
            learning_rate=0.03,
            max_depth=4,
            subsample=0.8,
            colsample_bytree=0.8,
            min_child_weight=8.0,
            gamma=0.0,
            reg_alpha=1e-6,
            reg_lambda=10.0,
            max_delta_step=0.0,
            objective="reg:squarederror",
            n_jobs=-1,
            tree_method="hist",
            eval_metric="rmse",
            early_stopping_rounds=int(XGB_EARLY_STOP_ROUNDS),
        )
        baseline_xgb = XGBRegressor(**baseline_params)

        def baseline_factory():
            return XGBRegressor(**baseline_params)

        r2_stat, _, _, _ = cv_stratified_curve_r2_and_gap(
            baseline_factory, X_train, y_train, df_train, preprocess, curve_meta_train
        )
        baseline_score = r2_stat
        print(f"\n=== Baseline XGB CV ({'median' if USE_MEDIAN_OBJECTIVE else 'mean'}) R2 = {baseline_score:.4f} ===")

    print("\n=== BO: RandomForest ===")
    rf_best_model, rf_best_params, rf_bo_target, rf_cv_r2, rf_gap, rf_r2_list, _ = run_bo(
        rf_pbounds,
        rf_build,
        X_train,
        y_train,
        df_train,
        preprocess,
        curve_meta_train,
        init_points=BO_INIT_POINTS,
        n_iter=BO_N_ITER,
    )

    prep = clone(preprocess)
    Xtr_m = prep.fit_transform(df_train[feature_cols])
    Xte_m = prep.transform(df_test[feature_cols])
    Xva_m = prep.transform(df_val[feature_cols])

    rf_best_model.fit(Xtr_m, df_train[Y_COL].to_numpy(float))
    ytr_pred = apply_constraints_pointwise(rf_best_model.predict(Xtr_m), df_train[TIME_COL].values)
    yte_pred = apply_constraints_pointwise(rf_best_model.predict(Xte_m), df_test[TIME_COL].values)
    yva_pred = apply_constraints_pointwise(rf_best_model.predict(Xva_m), df_val[TIME_COL].values)

    add_metrics_rows("RandomForest", "Train", df_train[Y_COL].to_numpy(float), ytr_pred)
    add_metrics_rows("RandomForest", "Test", df_test[Y_COL].to_numpy(float), yte_pred)
    add_metrics_rows("RandomForest", "Val", df_val[Y_COL].to_numpy(float), yva_pred)

    rf_train_r2 = float(r2_score(df_train[Y_COL], ytr_pred))
    rf_test_r2 = float(r2_score(df_test[Y_COL], yte_pred))
    rf_val_r2 = float(r2_score(df_val[Y_COL], yva_pred))

    joblib.dump(
        {"preprocess": prep, "model": rf_best_model, "feature_cols": feature_cols},
        os.path.join(out_models, "curve_split__RandomForest.pkl"),
    )

    save_best_params_json(
        out_params,
        "curve_split",
        "RandomForest",
        {
            "Best_Params": rf_best_params,
            "BO_Target": rf_bo_target,
            "CV_R2_stat": rf_cv_r2,
            "CV_R2_list": rf_r2_list,
            "Mean_Gap_stat": rf_gap,
            "Train_R2": rf_train_r2,
            "Test_R2": rf_test_r2,
            "Val_R2": rf_val_r2,
            "USE_GAP_PENALTY": USE_GAP_PENALTY,
            "USE_MEDIAN_OBJECTIVE": USE_MEDIAN_OBJECTIVE,
        },
    )

    if SAVE_VAL_PLOTS:
        plot_val_curves_per_model(
            "RandomForest",
            df_val,
            feature_cols,
            prep,
            rf_best_model,
            os.path.join(out_plots, "RandomForest"),
        )

    summary_rows.append(["RandomForest", rf_train_r2, rf_test_r2, rf_val_r2, rf_cv_r2])

    if HAS_XGB:
        print("\n=== BO: XGBoost ===")
        xgb_best_model, xgb_best_params, xgb_bo_target, xgb_cv_r2, xgb_gap, xgb_r2_list, _ = run_bo(
            xgb_pbounds,
            xgb_build,
            X_train,
            y_train,
            df_train,
            preprocess,
            curve_meta_train,
            init_points=BO_INIT_POINTS,
            n_iter=BO_N_ITER,
        )

        use_baseline = False
        if USE_BASELINE_FALLBACK and baseline_xgb is not None and (xgb_cv_r2 < baseline_score):
            print(f"[Fallback] BO CV_R2={xgb_cv_r2:.4f} < Baseline CV_R2={baseline_score:.4f} -> using Baseline XGB")
            use_baseline = True

        df_fit, df_hold = curve_internal_holdout(df_train, frac=XGB_INTERNAL_HOLDOUT_FRAC, seed=42)

        prep2 = clone(preprocess)
        Xfit_m = prep2.fit_transform(df_fit[feature_cols])
        yfit = df_fit[Y_COL].to_numpy(float)

        if use_baseline:
            model_final = XGBRegressor(**baseline_xgb.get_params())
        else:
            model_final = xgb_best_model

        if df_hold is not None and XGB_USE_EARLY_STOP:
            Xhold_m = prep2.transform(df_hold[feature_cols])
            yhold = df_hold[Y_COL].to_numpy(float)
            model_final.fit(Xfit_m, yfit, eval_set=[(Xhold_m, yhold)], verbose=False)
        else:
            model_final.fit(Xfit_m, yfit)

        Xtr2 = prep2.transform(df_train[feature_cols])
        Xte2 = prep2.transform(df_test[feature_cols])
        Xva2 = prep2.transform(df_val[feature_cols])

        ytr_pred = apply_constraints_pointwise(model_final.predict(Xtr2), df_train[TIME_COL].values)
        yte_pred = apply_constraints_pointwise(model_final.predict(Xte2), df_test[TIME_COL].values)
        yva_pred = apply_constraints_pointwise(model_final.predict(Xva2), df_val[TIME_COL].values)

        add_metrics_rows("XGBoost", "Train", df_train[Y_COL].to_numpy(float), ytr_pred)
        add_metrics_rows("XGBoost", "Test", df_test[Y_COL].to_numpy(float), yte_pred)
        add_metrics_rows("XGBoost", "Val", df_val[Y_COL].to_numpy(float), yva_pred)

        xgb_train_r2 = float(r2_score(df_train[Y_COL], ytr_pred))
        xgb_test_r2 = float(r2_score(df_test[Y_COL], yte_pred))
        xgb_val_r2 = float(r2_score(df_val[Y_COL], yva_pred))

        joblib.dump(
            {"preprocess": prep2, "model": model_final, "feature_cols": feature_cols},
            os.path.join(out_models, "curve_split__XGBoost.pkl"),
        )

        save_best_params_json(
            out_params,
            "curve_split",
            "XGBoost",
            {
                "Best_Params": xgb_best_params if not use_baseline else {"USED_BASELINE": True, **baseline_xgb.get_params()},
                "BO_Target": xgb_bo_target,
                "CV_R2_stat": xgb_cv_r2,
                "CV_R2_list": xgb_r2_list,
                "Mean_Gap_stat": xgb_gap,
                "Train_R2": xgb_train_r2,
                "Test_R2": xgb_test_r2,
                "Val_R2": xgb_val_r2,
                "USED_BASELINE_FALLBACK": use_baseline,
                "USE_GAP_PENALTY": USE_GAP_PENALTY,
                "USE_MEDIAN_OBJECTIVE": USE_MEDIAN_OBJECTIVE,
            },
        )

        if SAVE_VAL_PLOTS:
            plot_val_curves_per_model(
                "XGBoost",
                df_val,
                feature_cols,
                prep2,
                model_final,
                os.path.join(out_plots, "XGBoost"),
            )

        summary_rows.append(["XGBoost", xgb_train_r2, xgb_test_r2, xgb_val_r2, xgb_cv_r2])

    res_df = pd.DataFrame(summary_rows, columns=["Model", "Train_R2", "Test_R2", "Val_R2", "CV_R2_stat"])
    res_df = res_df.sort_values("Test_R2", ascending=False).reset_index(drop=True)
    out_xlsx = os.path.join(out_results, "summary_TESTR2_first.xlsx")
    res_df.to_excel(out_xlsx, index=False)

    metrics_df = pd.DataFrame(metrics_rows, columns=["Model", "Split", "MAE", "R2", "AE", "MSE", "MAPE(%)"])
    metrics_df["Split"] = pd.Categorical(metrics_df["Split"], categories=["Train", "Test", "Val"], ordered=True)
    metrics_df = metrics_df.sort_values(["Model", "Split"]).reset_index(drop=True)

    out_metrics_xlsx = os.path.join(out_results, "03_metrics_summary.xlsx")
    metrics_df.to_excel(out_metrics_xlsx, index=False)

    print("\n✅ Summary saved:", out_xlsx)
    print("✅ Metrics saved:", out_metrics_xlsx)
    print("\nR2 Summary:\n", res_df)
    print("\nMetrics Summary:\n", metrics_df)
    print("\nOutput directory:", output_root)


if __name__ == "__main__":
    main()
