import os
import re
import json
import joblib
import numpy as np
import pandas as pd

from bayes_opt import BayesianOptimization

from sklearn.model_selection import train_test_split, KFold, GroupKFold
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.base import clone

from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import GradientBoostingRegressor, AdaBoostRegressor

from catboost import CatBoostRegressor

try:
    from xgboost import XGBRegressor
    HAS_XGB = True
except Exception:
    HAS_XGB = False


np.random.seed(42)

file_path = r""
output_root = r""

VAL_SHEET_NAME = "Validation"

TIME_COL = "Time"
Y_COL = "degradation amount"

numeric_cols = ["Mw", "Ratio", "T", "pH", "SA/V", "LA_type", "Time"]
categorical_cols = ["Shape"]

RUN_POINT_SPLIT = False
RUN_CURVE_SPLIT = True

BO_INIT_POINTS = 10
BO_N_ITER = 60

CURVE_TEST_SIZE = 0.2
N_BINS = 5

APPLY_T0_ANCHOR = True
APPLY_NONNEG = True

SAVE_BEST_PARAMS_JSON = True
SAVE_BEST_PARAMS_SPLIT_EXCEL = True
SAVE_PREDICTIONS_EXCEL_PER_MODEL = True
SAVE_ALL_PREDICTIONS_LONG = True

STRICT_NO_LEAK = True


def safe_name(s: str) -> str:
    return re.sub(r"[^0-9A-Za-z]+", "_", str(s)).strip("_")


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.ndarray,)):
        return o.tolist()
    return str(o)


def add_curve_id_by_time0(df: pd.DataFrame, time_col: str):
    t = pd.to_numeric(df[time_col], errors="coerce").to_numpy(dtype=float)
    is_zero = np.isclose(t, 0.0, atol=1e-12)

    start_flags = np.zeros(len(df), dtype=bool)
    if len(df) > 0:
        start_flags[0] = True
    if len(df) > 1:
        start_flags[1:] = is_zero[1:] & (~is_zero[:-1])

    curve_id = np.cumsum(start_flags) - 1
    out = df.copy()
    out["curve_id"] = curve_id
    return out


def _clean_df_basic(df: pd.DataFrame) -> pd.DataFrame:
    df = df.loc[:, ~df.columns.str.contains("^Unnamed", na=False)].copy()
    if TIME_COL not in df.columns or Y_COL not in df.columns:
        raise ValueError(f"Missing required columns: {TIME_COL} or {Y_COL}")
    df[TIME_COL] = pd.to_numeric(df[TIME_COL], errors="coerce")
    df[Y_COL] = pd.to_numeric(df[Y_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL, Y_COL]).reset_index(drop=True)
    return df


def build_preprocess(df: pd.DataFrame):
    num_cols = list(numeric_cols)
    cat_cols = list(categorical_cols)

    if "LA_type" in df.columns:
        if (df["LA_type"].dtype == "object") or (df["LA_type"].nunique() <= 20):
            if "LA_type" in num_cols:
                num_cols.remove("LA_type")
            if "LA_type" not in cat_cols:
                cat_cols.append("LA_type")

    feature_cols = num_cols + cat_cols

    try:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)

    preprocess = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_cols),
            ("cat", ohe, cat_cols),
        ],
        remainder="drop",
    )
    return preprocess, feature_cols, num_cols, cat_cols


def apply_constraints_pointwise(y_pred_raw: np.ndarray, t_arr: np.ndarray):
    y = np.asarray(y_pred_raw, dtype=float).copy()
    t = np.asarray(t_arr, dtype=float)

    if APPLY_T0_ANCHOR:
        mask0 = np.isclose(t, 0.0, atol=1e-12)
        if not np.any(mask0):
            mask0 = (t == np.nanmin(t))
        y[mask0] = 0.0

    if APPLY_NONNEG:
        y = np.maximum(y, 0.0)

    return y


def check_overlap_by_hash(df_pool: pd.DataFrame, df_val: pd.DataFrame):
    common_cols = [c for c in df_pool.columns if c in df_val.columns]
    if len(common_cols) == 0:
        return 0, []

    pool_h = pd.util.hash_pandas_object(df_pool[common_cols], index=False)
    val_h = set(pd.util.hash_pandas_object(df_val[common_cols], index=False).tolist())
    overlap_mask = pool_h.isin(val_h)
    overlap_cnt = int(overlap_mask.sum())

    sample_rows = []
    if overlap_cnt > 0:
        sample_rows = df_pool.loc[overlap_mask, common_cols].head(5).to_dict(orient="records")
    return overlap_cnt, sample_rows


def build_curve_meta(df: pd.DataFrame):
    grp = df.groupby("curve_id", sort=True)
    meta = grp.agg(
        y_max=(Y_COL, "max"),
        y_min=(Y_COL, "min"),
        t_max=(TIME_COL, "max"),
        n_points=(Y_COL, "size"),
    ).reset_index()
    return meta


def stratified_curve_split(df_pool: pd.DataFrame, curve_meta: pd.DataFrame, test_size=0.2, n_bins=5, seed=42):
    meta_pool = curve_meta[curve_meta["curve_id"].isin(df_pool["curve_id"].unique())].copy()
    meta_pool = meta_pool.sort_values("curve_id").reset_index(drop=True)

    score = meta_pool["y_max"].to_numpy(dtype=float) + meta_pool["t_max"].to_numpy(dtype=float)
    try:
        bins = pd.qcut(score, q=n_bins, duplicates="drop")
    except Exception:
        bins = pd.cut(score, bins=min(n_bins, len(meta_pool)), duplicates="drop")

    meta_pool["bin"] = bins.astype(str)

    rng = np.random.RandomState(seed)
    train_ids, test_ids = [], []
    for _, g in meta_pool.groupby("bin"):
        ids = g["curve_id"].astype(int).tolist()
        rng.shuffle(ids)
        n_test = max(1, int(round(len(ids) * test_size))) if len(ids) > 1 else 0
        test_part = ids[:n_test]
        train_part = ids[n_test:]
        test_ids.extend(test_part)
        train_ids.extend(train_part)

    df_train = df_pool[df_pool["curve_id"].isin(train_ids)].copy()
    df_test = df_pool[df_pool["curve_id"].isin(test_ids)].copy()
    return df_train, df_test


def calc_metrics(y_true: np.ndarray, y_pred: np.ndarray):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_pred - y_true

    mae = float(mean_absolute_error(y_true, y_pred))
    r2 = float(r2_score(y_true, y_pred))
    ae = float(np.mean(err))
    mse = float(mean_squared_error(y_true, y_pred))

    denom = np.maximum(np.abs(y_true), 1e-6)
    mape = float(np.mean(np.abs(err) / denom) * 100.0)

    return {"MAE": mae, "R2": r2, "AE": ae, "MSE": mse, "MAPE": mape}


def fit_with_optional_evalset(model, X_tr, y_tr, X_va=None, y_va=None):
    if X_va is not None and y_va is not None:
        try:
            model.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)
            return
        except TypeError:
            pass
        try:
            model.fit(X_tr, y_tr, eval_set=(X_va, y_va))
            return
        except TypeError:
            pass
    model.fit(X_tr, y_tr)


def cv_constrained_r2_point(make_model_fn, X_df, y, preprocess, n_splits=5):
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    scores = []
    for tr_idx, va_idx in kf.split(X_df):
        X_tr = X_df.iloc[tr_idx].copy()
        y_tr = y[tr_idx]
        X_va = X_df.iloc[va_idx].copy()
        y_va = y[va_idx]

        prep = clone(preprocess)
        X_tr_m = prep.fit_transform(X_tr)
        X_va_m = prep.transform(X_va)

        model = make_model_fn()
        fit_with_optional_evalset(model, X_tr_m, y_tr, X_va_m, y_va)

        y_raw = model.predict(X_va_m)
        y_pred = apply_constraints_pointwise(y_raw, X_va[TIME_COL].values)
        scores.append(r2_score(y_va, y_pred))
    return float(np.mean(scores))


def cv_constrained_r2_curve(make_model_fn, X_df, y, groups, preprocess, n_splits=5):
    gkf = GroupKFold(n_splits=n_splits)
    scores = []
    for tr_idx, va_idx in gkf.split(X_df, y, groups):
        X_tr = X_df.iloc[tr_idx].copy()
        y_tr = y[tr_idx]
        X_va = X_df.iloc[va_idx].copy()
        y_va = y[va_idx]

        prep = clone(preprocess)
        X_tr_m = prep.fit_transform(X_tr)
        X_va_m = prep.transform(X_va)

        model = make_model_fn()
        fit_with_optional_evalset(model, X_tr_m, y_tr, X_va_m, y_va)

        y_raw = model.predict(X_va_m)
        y_pred = apply_constraints_pointwise(y_raw, X_va[TIME_COL].values)
        scores.append(r2_score(y_va, y_pred))
    return float(np.mean(scores))


def run_bo(pbounds, decode_and_build_model_fn, X_train_df, y_train, preprocess,
           cv_mode: str, groups_train=None, init_points=10, n_iter=60):
    def objective(**params):
        model = decode_and_build_model_fn(params)
        if cv_mode == "point":
            return cv_constrained_r2_point(lambda: model, X_train_df, y_train, preprocess, n_splits=5)
        return cv_constrained_r2_curve(lambda: model, X_train_df, y_train, groups_train, preprocess, n_splits=5)

    opt = BayesianOptimization(
        f=objective,
        pbounds=pbounds,
        random_state=42,
        allow_duplicate_points=True,
    )
    opt.maximize(init_points=init_points, n_iter=n_iter)

    best = opt.max
    best_params_raw = best["params"]
    best_cv_r2 = best["target"]
    best_model, best_params_decoded = decode_and_build_model_fn(best_params_raw, return_decoded=True)
    return best_model, best_params_decoded, best_cv_r2


def save_best_params_json(out_dir: str, split_mode: str, model_name: str, payload: dict) -> str:
    os.makedirs(out_dir, exist_ok=True)
    fn = f"{safe_name(split_mode)}__{safe_name(model_name)}__best_params.json"
    path = os.path.join(out_dir, fn)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=True, indent=2, default=_json_default)
    return path


def save_best_params_excels_by_split(res_df: pd.DataFrame, out_dir_results: str):
    for split in ["point_split", "curve_split"]:
        df_s = res_df[res_df["Split"] == split].copy()
        if df_s.empty:
            continue

        params_series = df_s.get("Best_Params_Dict", pd.Series([{}] * len(df_s)))
        params_series = params_series.apply(lambda x: x if isinstance(x, dict) else {})
        params_norm = pd.json_normalize(params_series)
        if params_norm.shape[1] > 0:
            params_norm.columns = [f"param__{c}" for c in params_norm.columns]

        base_cols = [
            "Split", "Model",
            "Best_CV_R2",
            "Train_R2", "Train_MSE",
            "Test_R2", "Test_MSE",
            "Val_R2(shared_val)", "Val_MSE(shared_val)",
            "Saved_PKL",
            "Best_Params_File",
            "Predictions_XLSX",
        ]
        base_cols = [c for c in base_cols if c in df_s.columns]
        base = df_s[base_cols].reset_index(drop=True)

        out_df = pd.concat([base, params_norm.reset_index(drop=True)], axis=1) if params_norm.shape[1] > 0 else base
        out_path = os.path.join(out_dir_results, f"best_params_{split}.xlsx")
        out_df.to_excel(out_path, index=False)
        print(f"Saved best-params summary: {out_path}")


def _make_pred_df(df_src: pd.DataFrame, y_true: np.ndarray, y_pred: np.ndarray,
                  split_mode: str, model_name: str, set_name: str, feature_cols: list) -> pd.DataFrame:
    out = df_src.copy()
    keep_cols = ["curve_id", TIME_COL] + [c for c in feature_cols if c in out.columns]
    keep_cols = list(dict.fromkeys(keep_cols))
    out = out[keep_cols].copy()

    out["Split"] = split_mode
    out["Model"] = model_name
    out["Set"] = set_name
    out["y_true"] = np.asarray(y_true, dtype=float)
    out["y_pred"] = np.asarray(y_pred, dtype=float)
    out["residual"] = out["y_pred"] - out["y_true"]
    out["abs_error"] = np.abs(out["residual"])
    return out


def save_predictions_excel_for_model(out_dir_pred: str, split_mode: str, model_name: str,
                                     df_train: pd.DataFrame, y_train: np.ndarray, y_train_pred: np.ndarray,
                                     df_test: pd.DataFrame, y_test: np.ndarray, y_test_pred: np.ndarray,
                                     df_val: pd.DataFrame, y_val: np.ndarray, y_val_pred: np.ndarray,
                                     feature_cols: list):
    os.makedirs(out_dir_pred, exist_ok=True)
    fn = f"predictions__{safe_name(split_mode)}__{safe_name(model_name)}.xlsx"
    path = os.path.join(out_dir_pred, fn)

    df_tr = _make_pred_df(df_train, y_train, y_train_pred, split_mode, model_name, "Train", feature_cols)
    df_te = _make_pred_df(df_test, y_test, y_test_pred, split_mode, model_name, "Test", feature_cols)
    df_va = _make_pred_df(df_val, y_val, y_val_pred, split_mode, model_name, "Val", feature_cols)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df_tr.to_excel(writer, sheet_name="Train", index=False)
        df_te.to_excel(writer, sheet_name="Test", index=False)
        df_va.to_excel(writer, sheet_name="Val", index=False)

    return path, df_tr, df_te, df_va


def fit_eval_save_one(
    split_mode: str, model_name: str,
    preprocess, feature_cols, num_cols, cat_cols,
    model, best_params, best_cv_r2,
    df_train: pd.DataFrame, df_test: pd.DataFrame,
    df_val: pd.DataFrame,
    out_dir_models: str,
    out_dir_best_params_json: str,
    out_dir_pred: str,
    all_pred_collector: list,
):
    X_train_df = df_train[feature_cols].copy()
    y_train = df_train[Y_COL].to_numpy(dtype=float)

    X_test_df = df_test[feature_cols].copy()
    y_test = df_test[Y_COL].to_numpy(dtype=float)

    X_val_df = df_val[feature_cols].copy()
    y_val = df_val[Y_COL].to_numpy(dtype=float)

    prep_full = clone(preprocess)
    X_train_m = prep_full.fit_transform(X_train_df)
    X_test_m = prep_full.transform(X_test_df)
    X_val_m = prep_full.transform(X_val_df)

    model.fit(X_train_m, y_train)

    y_train_raw = model.predict(X_train_m)
    y_train_pred = apply_constraints_pointwise(y_train_raw, X_train_df[TIME_COL].values)
    train_metrics = calc_metrics(y_train, y_train_pred)

    y_test_raw = model.predict(X_test_m)
    y_test_pred = apply_constraints_pointwise(y_test_raw, X_test_df[TIME_COL].values)
    test_metrics = calc_metrics(y_test, y_test_pred)

    y_val_raw = model.predict(X_val_m)
    y_val_pred = apply_constraints_pointwise(y_val_raw, X_val_df[TIME_COL].values)
    val_metrics = calc_metrics(y_val, y_val_pred)

    train_r2, train_mse = train_metrics["R2"], train_metrics["MSE"]
    test_r2, test_mse = test_metrics["R2"], test_metrics["MSE"]
    val_r2, val_mse = val_metrics["R2"], val_metrics["MSE"]

    os.makedirs(out_dir_models, exist_ok=True)
    pkl_name = f"{safe_name(split_mode)}__{safe_name(model_name)}.pkl"
    artifact = {
        "split_mode": split_mode,
        "preprocess": prep_full,
        "model": model,
        "best_cv_constrained_r2": float(best_cv_r2) if np.isfinite(best_cv_r2) else np.nan,
        "best_params": best_params,
        "feature_cols": feature_cols,
        "numeric_cols": num_cols,
        "categorical_cols": cat_cols,
        "time_col": TIME_COL,
        "target_col": Y_COL,
        "constraints": {"t0_to_zero": APPLY_T0_ANCHOR, "non_negative": APPLY_NONNEG},
    }
    joblib.dump(artifact, os.path.join(out_dir_models, pkl_name))

    best_params_file = ""
    if SAVE_BEST_PARAMS_JSON:
        payload = {
            "Split": split_mode,
            "Model": model_name,
            "Best_CV_R2": float(best_cv_r2) if np.isfinite(best_cv_r2) else None,
            "Train_R2": train_r2,
            "Test_R2": test_r2,
            "Val_R2(shared_val)": val_r2,
            "Train_MAE": train_metrics["MAE"],
            "Train_AE": train_metrics["AE"],
            "Train_MSE": train_metrics["MSE"],
            "Train_MAPE": train_metrics["MAPE"],
            "Test_MAE": test_metrics["MAE"],
            "Test_AE": test_metrics["AE"],
            "Test_MSE": test_metrics["MSE"],
            "Test_MAPE": test_metrics["MAPE"],
            "Val_MAE": val_metrics["MAE"],
            "Val_AE": val_metrics["AE"],
            "Val_MSE": val_metrics["MSE"],
            "Val_MAPE": val_metrics["MAPE"],
            "Best_Params_Decoded": best_params,
            "Final_Model_Params": model.get_params(),
            "Saved_PKL": pkl_name,
            "Constraints": {"t0_to_zero": APPLY_T0_ANCHOR, "non_negative": APPLY_NONNEG},
        }
        best_params_file = save_best_params_json(out_dir_best_params_json, split_mode, model_name, payload)

    pred_xlsx_path = ""
    if SAVE_PREDICTIONS_EXCEL_PER_MODEL:
        pred_xlsx_path, df_tr_pred, df_te_pred, df_va_pred = save_predictions_excel_for_model(
            out_dir_pred=out_dir_pred,
            split_mode=split_mode,
            model_name=model_name,
            df_train=df_train, y_train=y_train, y_train_pred=y_train_pred,
            df_test=df_test, y_test=y_test, y_test_pred=y_test_pred,
            df_val=df_val, y_val=y_val, y_val_pred=y_val_pred,
            feature_cols=feature_cols,
        )
        if SAVE_ALL_PREDICTIONS_LONG:
            all_pred_collector.extend([df_tr_pred, df_te_pred, df_va_pred])

    row = {
        "Split": split_mode,
        "Model": model_name,
        "Best_CV_R2": float(best_cv_r2) if np.isfinite(best_cv_r2) else np.nan,
        "Train_R2": train_r2, "Train_MSE": train_mse,
        "Test_R2": test_r2, "Test_MSE": test_mse,
        "Val_R2(shared_val)": val_r2, "Val_MSE(shared_val)": val_mse,
        "Train_MAE": train_metrics["MAE"],
        "Train_AE": train_metrics["AE"],
        "Train_MAPE": train_metrics["MAPE"],
        "Test_MAE": test_metrics["MAE"],
        "Test_AE": test_metrics["AE"],
        "Test_MAPE": test_metrics["MAPE"],
        "Val_MAE": val_metrics["MAE"],
        "Val_AE": val_metrics["AE"],
        "Val_MAPE": val_metrics["MAPE"],
        "Saved_PKL": pkl_name,
        "Best_Params_Dict": best_params if isinstance(best_params, dict) else {},
        "Best_Params_File": best_params_file,
        "Predictions_XLSX": pred_xlsx_path,
        "Train_rows": int(len(df_train)),
        "Test_rows": int(len(df_test)),
        "Val_rows": int(len(df_val)),
    }

    print(
        f"[{split_mode}] {model_name}: "
        f"Train_R2={train_r2:.4f} | Test_R2={test_r2:.4f} | Val_R2={val_r2:.4f} | Best_CV={best_cv_r2:.4f}"
    )
    return row


def get_model_specs():
    specs = []
    specs.append(("Linear Regression", None, None))

    def knn_build(params, return_decoded=False):
        n_neighbors = max(1, int(round(params["n_neighbors"])))
        leaf_size = max(1, int(round(params["leaf_size"])))
        decoded = {"n_neighbors": n_neighbors, "leaf_size": leaf_size, "weights": "distance", "n_jobs": -1}
        m = KNeighborsRegressor(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append(("KNN", {"n_neighbors": (2, 60), "leaf_size": (10, 80)}, knn_build))

    def svr_build(params, return_decoded=False):
        C = 10 ** params["log_C"]
        epsilon = 10 ** params["log_epsilon"]
        gamma = 10 ** params["log_gamma"]
        decoded = {"kernel": "rbf", "C": float(C), "epsilon": float(epsilon), "gamma": float(gamma)}
        m = SVR(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append(("SVR", {"log_C": (-0.3, 2.5), "log_epsilon": (-4.0, -0.7), "log_gamma": (-4.0, 0.0)}, svr_build))

    def dt_build(params, return_decoded=False):
        decoded = {
            "random_state": 42,
            "max_depth": max(1, int(round(params["max_depth"]))),
            "min_samples_split": max(2, int(round(params["min_samples_split"]))),
            "min_samples_leaf": max(1, int(round(params["min_samples_leaf"]))),
        }
        m = DecisionTreeRegressor(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append(("Decision Tree", {"max_depth": (2, 20), "min_samples_split": (2, 60), "min_samples_leaf": (1, 30)}, dt_build))

    def gbr_build(params, return_decoded=False):
        decoded = {
            "random_state": 42,
            "n_estimators": max(50, int(round(params["n_estimators"]))),
            "learning_rate": float(10 ** params["log_learning_rate"]),
            "subsample": float(np.clip(params["subsample"], 0.5, 1.0)),
            "max_depth": max(1, int(round(params["max_depth"]))),
            "min_samples_leaf": max(1, int(round(params["min_samples_leaf"]))),
            "max_features": float(np.clip(params["max_features"], 0.2, 1.0)),
        }
        m = GradientBoostingRegressor(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append((
        "Gradient Boosting",
        {
            "n_estimators": (100, 2000),
            "log_learning_rate": (-2.5, -0.7),
            "subsample": (0.5, 1.0),
            "max_depth": (2, 6),
            "min_samples_leaf": (1, 30),
            "max_features": (0.3, 1.0),
        },
        gbr_build,
    ))

    def ada_build(params, return_decoded=False):
        n_estimators = max(50, int(round(params["n_estimators"])))
        lr = float(10 ** params["log_learning_rate"])
        base_max_depth = max(1, int(round(params["base_max_depth"])))
        base = DecisionTreeRegressor(random_state=42, max_depth=base_max_depth)
        try:
            m = AdaBoostRegressor(random_state=42, estimator=base, n_estimators=n_estimators, learning_rate=lr, loss="linear")
        except TypeError:
            m = AdaBoostRegressor(random_state=42, base_estimator=base, n_estimators=n_estimators, learning_rate=lr, loss="linear")
        decoded = {"n_estimators": n_estimators, "learning_rate": lr, "base_max_depth": base_max_depth}
        return (m, decoded) if return_decoded else m

    specs.append(("AdaBoost", {"n_estimators": (50, 1500), "log_learning_rate": (-2.0, 0.0), "base_max_depth": (1, 6)}, ada_build))

    def ridge_build(params, return_decoded=False):
        alpha = float(10 ** params["log_alpha"])
        decoded = {"alpha": alpha}
        m = Ridge(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append(("Ridge", {"log_alpha": (-6.0, 2.0)}, ridge_build))

    def lasso_build(params, return_decoded=False):
        alpha = float(10 ** params["log_alpha"])
        decoded = {"alpha": alpha, "max_iter": 5000}
        m = Lasso(**decoded)
        return (m, decoded) if return_decoded else m

    specs.append(("Lasso", {"log_alpha": (-7.0, 0.0)}, lasso_build))

    def decode_cat_params(p, bootstrap_type: str):
        iterations = max(800, int(round(p["iterations"])))
        depth = max(2, int(round(p["depth"])))
        min_data_in_leaf = max(1, int(round(p["min_data_in_leaf"])))

        lr = 10 ** p["log_lr"]
        l2 = 10 ** p["log_l2"]
        rs = 10 ** p["log_rs"]

        params = dict(
            bootstrap_type=bootstrap_type,
            iterations=iterations,
            learning_rate=float(lr),
            depth=depth,
            l2_leaf_reg=float(l2),
            min_data_in_leaf=min_data_in_leaf,
            rsm=float(p["rsm"]),
            random_strength=float(rs),
            loss_function="RMSE",
            random_seed=42,
            verbose=False,
            allow_writing_files=False,
            thread_count=-1,
            use_best_model=True,
            od_type="Iter",
            od_wait=50,
        )

        if bootstrap_type == "Bayesian":
            params["bagging_temperature"] = float(p["bagging_temperature"])
        else:
            params["subsample"] = float(p["subsample"])
        return params

    cat_common = dict(
        iterations=(800, 12000),
        depth=(3, 10),
        min_data_in_leaf=(1, 60),
        rsm=(0.5, 1.0),
        log_lr=(-2.5, -0.7),
        log_l2=(-1.0, 2.78),
        log_rs=(-3.0, 1.48),
    )

    def cat_build_factory(bootstrap_type: str):
        pb = dict(cat_common)
        if bootstrap_type == "Bayesian":
            pb["bagging_temperature"] = (0.0, 20.0)
        else:
            pb["subsample"] = (0.5, 1.0)

        def build(params, return_decoded=False):
            decoded = decode_cat_params(params, bootstrap_type)
            m = CatBoostRegressor(**decoded)
            return (m, decoded) if return_decoded else m

        return pb, build

    specs.append(("CatBoost", ("_special_catboost_", cat_build_factory), None))
    return specs


def main():
    os.makedirs(output_root, exist_ok=True)

    out_dir_meta = os.path.join(output_root, "00_meta")
    out_dir_models = os.path.join(output_root, "01_models")
    out_dir_results = os.path.join(output_root, "02_results")
    out_dir_best_params_json = os.path.join(output_root, "04_best_params_json")
    out_dir_pred = os.path.join(output_root, "05_predictions_excels")

    for d in [out_dir_meta, out_dir_models, out_dir_results, out_dir_best_params_json, out_dir_pred]:
        os.makedirs(d, exist_ok=True)

    sheets = pd.read_excel(file_path, sheet_name=None, engine="openpyxl")
    if VAL_SHEET_NAME not in sheets:
        raise ValueError(f"Sheet not found in Excel: {VAL_SHEET_NAME}")

    df_val = _clean_df_basic(sheets[VAL_SHEET_NAME])

    train_parts = []
    used_pool_sheets = []
    for name, df_sheet in sheets.items():
        if name == VAL_SHEET_NAME:
            continue
        df_sheet = df_sheet.loc[:, ~df_sheet.columns.str.contains("^Unnamed", na=False)].copy()
        if TIME_COL in df_sheet.columns and Y_COL in df_sheet.columns:
            train_parts.append(_clean_df_basic(df_sheet))
            used_pool_sheets.append(name)

    if len(train_parts) == 0:
        raise ValueError(f"No training sheets found (excluding '{VAL_SHEET_NAME}') containing {TIME_COL}/{Y_COL}.")

    df_pool = pd.concat(train_parts, axis=0, ignore_index=True)

    if "curve_id" not in df_pool.columns:
        df_pool = add_curve_id_by_time0(df_pool, TIME_COL)
    if "curve_id" not in df_val.columns:
        df_val = add_curve_id_by_time0(df_val, TIME_COL)

    overlap_cnt, samples = check_overlap_by_hash(df_pool, df_val)
    print(f"[LeakCheck] Pool-VAL overlap rows = {overlap_cnt}")
    if overlap_cnt > 0:
        print("[LeakCheck] overlap sample rows (first 5):", samples)
        msg = (
            "Training pool still contains rows that match the validation set (potential data leakage). "
            "If the validation set was extracted from the original data, this should be 0. "
            "Please check whether the validation rows still exist in other sheets or there are duplicates."
        )
        if STRICT_NO_LEAK:
            raise ValueError(msg)
        print("WARNING:", msg)

    df_all_for_schema = pd.concat([df_pool, df_val], axis=0, ignore_index=True)
    preprocess, feature_cols, num_cols, cat_cols = build_preprocess(df_all_for_schema)

    missing_cols = [c for c in feature_cols if c not in df_pool.columns or c not in df_val.columns]
    if missing_cols:
        raise ValueError(
            f"Missing feature columns in training or validation data: {missing_cols}\n"
            f"pool_sheets={used_pool_sheets}; val_sheet={VAL_SHEET_NAME}"
        )

    curve_meta = build_curve_meta(df_pool)

    df_pool.to_excel(os.path.join(out_dir_meta, "df_pool.xlsx"), index=False)
    df_val.to_excel(os.path.join(out_dir_meta, "df_val.xlsx"), index=False)

    specs = get_model_specs()
    all_rows = []
    all_pred_collector = []

    if RUN_POINT_SPLIT:
        split_mode = "point_split"
        df_train, df_test = train_test_split(df_pool, test_size=0.2, random_state=42)

        X_train_df = df_train[feature_cols].copy()
        y_train = df_train[Y_COL].to_numpy(dtype=float)

        for name, pb, builder in specs:
            if name == "CatBoost":
                _, cat_factory = pb
                pb_bayes, build_bayes = cat_factory("Bayesian")
                pb_bern, build_bern = cat_factory("Bernoulli")

                m1, p1, cv1 = run_bo(pb_bayes, build_bayes, X_train_df, y_train, preprocess, cv_mode="point",
                                     init_points=BO_INIT_POINTS, n_iter=BO_N_ITER)
                m2, p2, cv2 = run_bo(pb_bern, build_bern, X_train_df, y_train, preprocess, cv_mode="point",
                                     init_points=BO_INIT_POINTS, n_iter=BO_N_ITER)

                if cv1 >= cv2:
                    best_model, best_params, best_cv = m1, p1, cv1
                    best_params = dict(best_params)
                    best_params["chosen_bootstrap"] = "Bayesian"
                else:
                    best_model, best_params, best_cv = m2, p2, cv2
                    best_params = dict(best_params)
                    best_params["chosen_bootstrap"] = "Bernoulli"

                final_params = dict(best_model.get_params())
                final_params.pop("use_best_model", None)
                final_params.pop("od_type", None)
                final_params.pop("od_wait", None)
                final_model = CatBoostRegressor(**final_params)

                row = fit_eval_save_one(
                    split_mode, "CatBoost",
                    preprocess, feature_cols, num_cols, cat_cols,
                    final_model, best_params, best_cv,
                    df_train, df_test, df_val,
                    out_dir_models=os.path.join(out_dir_models, split_mode),
                    out_dir_best_params_json=out_dir_best_params_json,
                    out_dir_pred=os.path.join(out_dir_pred, split_mode),
                    all_pred_collector=all_pred_collector,
                )
                all_rows.append(row)
                continue

            if name == "Linear Regression":
                model = LinearRegression()
                row = fit_eval_save_one(
                    split_mode, name,
                    preprocess, feature_cols, num_cols, cat_cols,
                    model, best_params={}, best_cv_r2=np.nan,
                    df_train=df_train, df_test=df_test, df_val=df_val,
                    out_dir_models=os.path.join(out_dir_models, split_mode),
                    out_dir_best_params_json=out_dir_best_params_json,
                    out_dir_pred=os.path.join(out_dir_pred, split_mode),
                    all_pred_collector=all_pred_collector,
                )
                all_rows.append(row)
                continue

            best_model, best_params, best_cv = run_bo(
                pb, builder, X_train_df, y_train, preprocess,
                cv_mode="point", groups_train=None,
                init_points=BO_INIT_POINTS, n_iter=BO_N_ITER,
            )
            row = fit_eval_save_one(
                split_mode, name,
                preprocess, feature_cols, num_cols, cat_cols,
                best_model, best_params, best_cv,
                df_train, df_test, df_val,
                out_dir_models=os.path.join(out_dir_models, split_mode),
                out_dir_best_params_json=out_dir_best_params_json,
                out_dir_pred=os.path.join(out_dir_pred, split_mode),
                all_pred_collector=all_pred_collector,
            )
            all_rows.append(row)

    if RUN_CURVE_SPLIT:
        split_mode = "curve_split"
        df_train, df_test = stratified_curve_split(df_pool, curve_meta, test_size=CURVE_TEST_SIZE, n_bins=N_BINS, seed=42)

        X_train_df = df_train[feature_cols].copy()
        y_train = df_train[Y_COL].to_numpy(dtype=float)
        groups_train = df_train["curve_id"].to_numpy()

        for name, pb, builder in specs:
            if name == "CatBoost":
                _, cat_factory = pb
                pb_bayes, build_bayes = cat_factory("Bayesian")
                pb_bern, build_bern = cat_factory("Bernoulli")

                m1, p1, cv1 = run_bo(pb_bayes, build_bayes, X_train_df, y_train, preprocess,
                                     cv_mode="curve", groups_train=groups_train,
                                     init_points=BO_INIT_POINTS, n_iter=BO_N_ITER)
                m2, p2, cv2 = run_bo(pb_bern, build_bern, X_train_df, y_train, preprocess,
                                     cv_mode="curve", groups_train=groups_train,
                                     init_points=BO_INIT_POINTS, n_iter=BO_N_ITER)

                if cv1 >= cv2:
                    best_model, best_params, best_cv = m1, p1, cv1
                    best_params = dict(best_params)
                    best_params["chosen_bootstrap"] = "Bayesian"
                else:
                    best_model, best_params, best_cv = m2, p2, cv2
                    best_params = dict(best_params)
                    best_params["chosen_bootstrap"] = "Bernoulli"

                final_params = dict(best_model.get_params())
                final_params.pop("use_best_model", None)
                final_params.pop("od_type", None)
                final_params.pop("od_wait", None)
                final_model = CatBoostRegressor(**final_params)

                row = fit_eval_save_one(
                    split_mode, "CatBoost",
                    preprocess, feature_cols, num_cols, cat_cols,
                    final_model, best_params, best_cv,
                    df_train, df_test, df_val,
                    out_dir_models=os.path.join(out_dir_models, split_mode),
                    out_dir_best_params_json=out_dir_best_params_json,
                    out_dir_pred=os.path.join(out_dir_pred, split_mode),
                    all_pred_collector=all_pred_collector,
                )
                all_rows.append(row)
                continue

            if name == "Linear Regression":
                model = LinearRegression()
                row = fit_eval_save_one(
                    split_mode, name,
                    preprocess, feature_cols, num_cols, cat_cols,
                    model, best_params={}, best_cv_r2=np.nan,
                    df_train=df_train, df_test=df_test, df_val=df_val,
                    out_dir_models=os.path.join(out_dir_models, split_mode),
                    out_dir_best_params_json=out_dir_best_params_json,
                    out_dir_pred=os.path.join(out_dir_pred, split_mode),
                    all_pred_collector=all_pred_collector,
                )
                all_rows.append(row)
                continue

            best_model, best_params, best_cv = run_bo(
                pb, builder, X_train_df, y_train, preprocess,
                cv_mode="curve", groups_train=groups_train,
                init_points=BO_INIT_POINTS, n_iter=BO_N_ITER,
            )
            row = fit_eval_save_one(
                split_mode, name,
                preprocess, feature_cols, num_cols, cat_cols,
                best_model, best_params, best_cv,
                df_train, df_test, df_val,
                out_dir_models=os.path.join(out_dir_models, split_mode),
                out_dir_best_params_json=out_dir_best_params_json,
                out_dir_pred=os.path.join(out_dir_pred, split_mode),
                all_pred_collector=all_pred_collector,
            )
            all_rows.append(row)

    res = pd.DataFrame(all_rows)
    res_sorted = res.sort_values(["Split", "Val_R2(shared_val)"], ascending=[True, False]).reset_index(drop=True)

    out_results_xlsx = os.path.join(output_root, "02_results", "results_point_and_curve_with_shared_val.xlsx")
    res_sorted.to_excel(out_results_xlsx, index=False)
    print("\nSaved results:", out_results_xlsx)

    metric_cols = [
        "Split", "Model", "Best_CV_R2",
        "Train_MAE", "Train_R2", "Train_AE", "Train_MSE", "Train_MAPE",
        "Test_MAE", "Test_R2", "Test_AE", "Test_MSE", "Test_MAPE",
        "Val_MAE", "Val_R2(shared_val)", "Val_AE", "Val_MSE(shared_val)", "Val_MAPE",
        "Saved_PKL", "Predictions_XLSX",
    ]
    metric_cols = [c for c in metric_cols if c in res_sorted.columns]
    metrics_summary = res_sorted[metric_cols].copy()

    out_metrics_xlsx = os.path.join(output_root, "02_results", "metrics_train_test_val_summary.xlsx")
    metrics_summary.to_excel(out_metrics_xlsx, index=False)
    print("Saved metrics summary:", out_metrics_xlsx)

    if SAVE_BEST_PARAMS_SPLIT_EXCEL:
        save_best_params_excels_by_split(res_sorted, os.path.join(output_root, "02_results"))

    if SAVE_ALL_PREDICTIONS_LONG and len(all_pred_collector) > 0:
        all_pred_long = pd.concat(all_pred_collector, axis=0, ignore_index=True)
        out_pred_long = os.path.join(output_root, "02_results", "all_predictions_long.xlsx")
        all_pred_long.to_excel(out_pred_long, index=False)
        print("Saved all-model prediction long table:", out_pred_long)

    print("\n==========================")
    print("Output directory:", output_root)
    print("Best-params JSON folder: 04_best_params_json")
    print("Per-model prediction Excels: 05_predictions_excels/<split>/predictions__<split>__<model>.xlsx")
    print("All-model prediction long table: 02_results/all_predictions_long.xlsx")
    print("Metrics summary: 02_results/metrics_train_test_val_summary.xlsx")
    print("==========================\n")


if __name__ == "__main__":
    main()
