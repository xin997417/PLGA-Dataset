import os
import re
import joblib
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor
from bayes_opt import BayesianOptimization

from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, PolynomialFeatures
from sklearn.pipeline import Pipeline
from sklearn.base import clone


np.random.seed(42)

FILE_PATH = r""
OUTPUT_DIR = r""

TRAIN_SHEET = 0
VAL_SHEET = 1

TIME_COL = "Time"
Y_COL = "degradation amount"

FEATURE_NUMERIC = ["Mw", "Ratio", "T", "pH", "SA/V", "LA_type", "Time"]
FEATURE_CATEGORICAL = ["Shape"]

USE_INTERACTIONS = True
POLY_DEGREE = 2
INTERACTION_ONLY = True

TEST_SIZE = 0.2

APPLY_T0_ANCHOR = True
APPLY_NONNEG = True

BO_INIT_POINTS = 8
BO_N_ITER = 40

matplotlib.rcParams["font.sans-serif"] = ["DejaVu Sans", "Arial"]
matplotlib.rcParams["axes.unicode_minus"] = False


def safe_name(s: str) -> str:
    return re.sub(r"[^0-9A-Za-z]+", "_", str(s)).strip("_")


def add_curve_id_by_time0(df: pd.DataFrame, time_col: str) -> pd.DataFrame:
    t = pd.to_numeric(df[time_col], errors="coerce").to_numpy(dtype=float)
    is_zero = np.isclose(t, 0.0, atol=1e-12)
    start_flags = np.zeros(len(df), dtype=bool)

    if len(df) > 0:
        start_flags[0] = True
    if len(df) > 1:
        start_flags[1:] = is_zero[1:] & (~is_zero[:-1])

    curve_id = np.cumsum(start_flags) - 1
    out = df.copy()
    out["curve_id"] = curve_id
    return out


def apply_constraints_pointwise(y_pred_raw: np.ndarray, t_arr: np.ndarray) -> np.ndarray:
    y = np.asarray(y_pred_raw, dtype=float).copy()
    t = np.asarray(t_arr, dtype=float)

    if APPLY_T0_ANCHOR:
        mask0 = np.isclose(t, 0.0, atol=1e-12)
        y[mask0] = 0.0

    if APPLY_NONNEG:
        y = np.maximum(y, 0.0)

    return y


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    err = y_pred - y_true

    mae = float(np.mean(np.abs(err)))
    ae = float(np.mean(err))
    mse = float(np.mean(err ** 2))
    rmse = float(np.sqrt(mse))

    if len(y_true) >= 2:
        r2 = float(r2_score(y_true, y_pred))
    else:
        r2 = float("nan")

    mask = np.abs(y_true) > 1e-12
    if np.any(mask):
        mape = float(np.mean(np.abs(err[mask] / y_true[mask])) * 100.0)
    else:
        mape = float("nan")

    return {"MAE": mae, "AE": ae, "R2": r2, "RMSE": rmse, "MSE": mse, "MAPE": mape}


def metrics_text_block(m: dict) -> str:
    def f(x):
        return "NaN" if (x is None or (isinstance(x, float) and not np.isfinite(x))) else f"{x:.5g}"

    return (
        f"MAE : {f(m['MAE'])}\n"
        f"AE  : {f(m['AE'])}\n"
        f"R2  : {f(m['R2'])}\n"
        f"RMSE: {f(m['RMSE'])}\n"
        f"MSE : {f(m['MSE'])}\n"
        f"MAPE: {f(m['MAPE'])}%"
    )


def build_preprocess():
    num_cols = list(FEATURE_NUMERIC)
    cat_cols = list(FEATURE_CATEGORICAL)

    try:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        ohe = OneHotEncoder(handle_unknown="ignore", sparse=False)

    ct = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), num_cols),
            ("cat", ohe, cat_cols),
        ],
        remainder="drop"
    )

    if USE_INTERACTIONS:
        poly = PolynomialFeatures(degree=POLY_DEGREE, include_bias=False, interaction_only=INTERACTION_ONLY)
        preprocess = Pipeline([
            ("ct", ct),
            ("poly", poly),
        ])
    else:
        preprocess = ct

    feature_cols = num_cols + cat_cols
    return preprocess, feature_cols


def cv_constrained_r2_point(make_model_fn, X_df, y, preprocess, n_splits=5):
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    scores = []

    for tr_idx, va_idx in kf.split(X_df):
        X_tr = X_df.iloc[tr_idx].copy()
        y_tr = y[tr_idx]
        X_va = X_df.iloc[va_idx].copy()
        y_va = y[va_idx]

        prep = clone(preprocess)
        X_tr_m = prep.fit_transform(X_tr)
        X_va_m = prep.transform(X_va)

        model = make_model_fn()
        model.fit(X_tr_m, y_tr)

        y_raw = model.predict(X_va_m)
        y_pred = apply_constraints_pointwise(y_raw, X_va[TIME_COL].values)
        scores.append(r2_score(y_va, y_pred))

    return float(np.mean(scores))


def run_bo(pbounds, decode_and_build_model_fn, X_train_df, y_train, preprocess, init_points=10, n_iter=70):
    def objective(**params):
        model = decode_and_build_model_fn(params)
        return cv_constrained_r2_point(lambda: model, X_train_df, y_train, preprocess, n_splits=5)

    opt = BayesianOptimization(
        f=objective,
        pbounds=pbounds,
        random_state=42,
        allow_duplicate_points=True
    )
    opt.maximize(init_points=init_points, n_iter=n_iter)

    best = opt.max
    best_params_raw = best["params"]
    best_cv_r2 = best["target"]
    best_model, best_params_decoded = decode_and_build_model_fn(best_params_raw, return_decoded=True)

    return best_model, best_params_decoded, best_cv_r2


def get_model_specs():
    specs = []

    def rf_build(p, return_decoded=False):
        decoded = {
            "random_state": 42,
            "n_jobs": -1,
            "n_estimators": int(round(p["n_estimators"])),
            "max_depth": int(round(p["max_depth"])),
            "min_samples_split": int(round(p["min_samples_split"])),
            "min_samples_leaf": int(round(p["min_samples_leaf"])),
            "max_features": float(p["max_features"])
        }

        m = RandomForestRegressor(**decoded)
        return (m, decoded) if return_decoded else m

    rf_bounds = {
        "n_estimators": (50, 400),
        "max_depth": (3, 20),
        "min_samples_split": (2, 20),
        "min_samples_leaf": (1, 10),
        "max_features": (0.3, 0.9)
    }

    specs.append(("Random Forest", rf_bounds, rf_build))
    return specs


def plot_val_curves_for_model(model_name: str, prep_fitted, model_fitted, df_val: pd.DataFrame,
                              feature_cols: list, out_dir: str) -> pd.DataFrame:
    os.makedirs(out_dir, exist_ok=True)
    rows = []

    curve_ids = sorted(df_val["curve_id"].unique().tolist())
    print(f"   Plotting {len(curve_ids)} curves for {model_name}...")

    for i, cid in enumerate(curve_ids, start=1):
        g = df_val[df_val["curve_id"] == cid].copy()
        g[TIME_COL] = pd.to_numeric(g[TIME_COL], errors="coerce")
        if Y_COL in g.columns:
            g[Y_COL] = pd.to_numeric(g[Y_COL], errors="coerce")
        g = g.dropna(subset=[TIME_COL]).sort_values(TIME_COL)

        if len(g) == 0:
            continue

        X_df = g[feature_cols].copy()
        t_arr = X_df[TIME_COL].to_numpy(dtype=float)

        X_m = prep_fitted.transform(X_df)
        y_raw = model_fitted.predict(X_m)
        y_pred = apply_constraints_pointwise(y_raw, t_arr)

        y_true = None
        m = {"MAE": np.nan, "AE": np.nan, "R2": np.nan, "RMSE": np.nan, "MSE": np.nan, "MAPE": np.nan}

        if Y_COL in g.columns and g[Y_COL].notna().all():
            y_true = g[Y_COL].to_numpy(dtype=float)
            m = compute_metrics(y_true, y_pred)

        rows.append({
            "Model": model_name,
            "curve_id": int(cid),
            "n_points": int(len(g)),
            **m
        })

        fig, ax = plt.subplots(figsize=(8, 5))
        if y_true is not None:
            ax.plot(t_arr, y_true, "o-", color="black", label="True", markersize=5, alpha=0.7)

        ax.plot(t_arr, y_pred, "^--", color="forestgreen", label="Pred (RF)", markersize=5)

        ax.set_title(f"{model_name} | Val Curve #{int(cid)}", fontsize=12)
        ax.set_xlabel(TIME_COL)
        ax.set_ylabel(Y_COL)
        ax.grid(True, linestyle="--", alpha=0.4)
        ax.legend(loc="upper left")

        ax.text(
            0.98, 0.02,
            metrics_text_block(m),
            transform=ax.transAxes,
            ha="right", va="bottom",
            fontsize=10,
            family="monospace",
            bbox=dict(boxstyle="round,pad=0.5", facecolor="white", alpha=0.9, edgecolor="gray")
        )

        plt.tight_layout()
        save_name = f"Val_Curve_{i}_ID{int(cid)}.png"
        plt.savefig(os.path.join(out_dir, save_name), dpi=300)
        plt.close(fig)

    return pd.DataFrame(rows)


def main():
    if os.path.exists(OUTPUT_DIR):
        print(f"Warning: Output dir {OUTPUT_DIR} exists.")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    out_models = os.path.join(OUTPUT_DIR, "models_pkl")
    out_plots = os.path.join(OUTPUT_DIR, "val_plots")
    os.makedirs(out_models, exist_ok=True)
    os.makedirs(out_plots, exist_ok=True)

    print(f"--- Loading data from {FILE_PATH} ---")

    df_train_all = pd.read_excel(FILE_PATH, sheet_name=TRAIN_SHEET, engine="openpyxl")
    df_train_all = df_train_all.loc[:, ~df_train_all.columns.str.contains("^Unnamed", na=False)].copy()

    for c in FEATURE_NUMERIC + [Y_COL]:
        df_train_all[c] = pd.to_numeric(df_train_all[c], errors="coerce")
    df_train_all = df_train_all.dropna(subset=FEATURE_NUMERIC + FEATURE_CATEGORICAL + [Y_COL]).reset_index(drop=True)

    print(f"Training sheet loaded: {df_train_all.shape}")

    df_val = pd.read_excel(FILE_PATH, sheet_name=VAL_SHEET, engine="openpyxl")
    df_val = df_val.loc[:, ~df_val.columns.str.contains("^Unnamed", na=False)].copy()

    if df_val.shape[1] >= 2:
        print("Note: Removing first column of validation sheet (index column).")
        df_val = df_val.iloc[:, 1:].copy()

    for c in FEATURE_NUMERIC:
        if c in df_val.columns:
            df_val[c] = pd.to_numeric(df_val[c], errors="coerce")
    if Y_COL in df_val.columns:
        df_val[Y_COL] = pd.to_numeric(df_val[Y_COL], errors="coerce")

    df_val = df_val.dropna(subset=[TIME_COL]).reset_index(drop=True)
    df_val = add_curve_id_by_time0(df_val, TIME_COL)
    print(f"Validation sheet loaded: {df_val.shape}, found {df_val['curve_id'].nunique()} curves.")

    preprocess, feature_cols = build_preprocess()

    df_train, df_test = train_test_split(df_train_all, test_size=TEST_SIZE, random_state=42, shuffle=True)

    X_train_df = df_train[feature_cols].copy()
    y_train = df_train[Y_COL].to_numpy(dtype=float)
    X_test_df = df_test[feature_cols].copy()
    y_test = df_test[Y_COL].to_numpy(dtype=float)

    specs = get_model_specs()

    results_summary = []
    val_metrics_all = []

    for name, pbounds, builder in specs:
        print(f"\n>>> Optimizing {name} with BayesOpt ({BO_N_ITER} iterations)...")

        best_model, best_params, best_cv_r2 = run_bo(
            pbounds, builder, X_train_df, y_train, preprocess,
            init_points=BO_INIT_POINTS, n_iter=BO_N_ITER
        )

        print(f"   Best CV R2: {best_cv_r2:.4f}")
        print(f"   Best Params: {best_params}")

        prep_fit = clone(preprocess)
        X_train_m = prep_fit.fit_transform(X_train_df)
        X_test_m = prep_fit.transform(X_test_df)

        best_model.fit(X_train_m, y_train)

        y_tr_pred = apply_constraints_pointwise(best_model.predict(X_train_m), X_train_df[TIME_COL])
        tr_m = compute_metrics(y_train, y_tr_pred)

        y_te_pred = apply_constraints_pointwise(best_model.predict(X_test_m), X_test_df[TIME_COL])
        te_m = compute_metrics(y_test, y_te_pred)

        print(f"   [Train/Test split] Train R2={tr_m['R2']:.4f}, Test R2={te_m['R2']:.4f}")

        joblib.dump(
            {
                "model": best_model,
                "preprocess": prep_fit,
                "params": best_params,
                "features": feature_cols
            },
            os.path.join(out_models, f"{safe_name(name)}_model.pkl")
        )

        val_rows = plot_val_curves_for_model(name, prep_fit, best_model, df_val, feature_cols, out_plots)
        val_metrics_all.append(val_rows)

        results_summary.append(
            {
                "Model": name,
                "CV_R2": best_cv_r2,
                "Train_R2": tr_m["R2"], "Train_RMSE": tr_m["RMSE"], "Train_MAE": tr_m["MAE"],
                "Test_R2": te_m["R2"], "Test_RMSE": te_m["RMSE"], "Test_MAE": te_m["MAE"],
                "Best_Params": str(best_params)
            }
        )

    df_res = pd.DataFrame(results_summary)
    df_res.to_excel(os.path.join(OUTPUT_DIR, "Summary_Metrics.xlsx"), index=False)

    if val_metrics_all:
        df_val_all = pd.concat(val_metrics_all, axis=0)
        df_val_all.to_excel(os.path.join(OUTPUT_DIR, "Validation_Curves_Metrics.xlsx"), index=False)

    print("\nAll done!")
    print(f"Results saved in: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
